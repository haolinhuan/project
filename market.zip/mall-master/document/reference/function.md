# mall功能结构说明

## 后台管理系统

### 商品管理

![功能结构图-商品.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_product.jpg)

### 订单管理

![功能结构图-订单.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_order.jpg)

### 促销管理

![功能结构图-促销.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_sale.jpg)

### 内容管理

![功能结构图-内容.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_content.jpg)

### 用户管理

![功能结构图-用户.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_member.jpg)

## 前台商城系统 

![功能结构图-前台.jpg](https://github.com/macrozheng/mall/blob/master/document/resource/mind_portal.jpg)