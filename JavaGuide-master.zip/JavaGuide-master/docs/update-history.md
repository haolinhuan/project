**2020-03-07** 

[refer](https://github.com/Snailclimb/JavaGuide/commit/9e6424ffd63cd6664a03dd84ec1a9dc32cf3b2e5)

将面试指南部分的文章移除，避免JavaGuide因为内容的膨胀而过于臃肿。移除部分目前是通过 PDF 文档的形式来分享，详见[JavaGuide面试突击版](./javaguide面试突击版.md)。

**2020-02-29**

[refer](https://github.com/Snailclimb/JavaGuide/commit/e86ee6761dc5fe03f410711b28bc3a119e9ff731)

对整体知识体系结构进行了调整和完善。

